1	¿Qué es la visualización de datos?									
	El papel de la visualización de datos									
	Tipos de datos (numéricos, texto, imágenes, sonido)									
2	Tipos de variables (discretas, continuas, categóricas)									
	Herramientas para análisis y visualización de datos, tablas dinámicas y lectura de datos									
3	Visualización de datos categóricos (tablas, gráficas de barras, gráficas de pie)									
	Visualización de datos numéricos									
4	Estadística descriptiva, histogramas y diagramas de caja y bigotes									
5	Visualización de datos univariantes: tipos de distribuciones, normalidad, valores atípicos y la paradoja de Simpson									
6	Presentaciones intermedias de los análisis y visualizaciones de la situación problema									
7	Visualización de datos multivariantes (comparación de histogramas, diagramas de dispersión)									
8	Modelos de regresión									
	Histogramas de residuos									
9	Diseño de tableros de mando (dashboards)									
10	Presentaciones finales									